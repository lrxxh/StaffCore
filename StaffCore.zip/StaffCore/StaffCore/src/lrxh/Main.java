package lrxh;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

import lrxh.Commands.ClearChat;
import lrxh.Commands.CpsCounter;
import lrxh.Commands.Fly;
import lrxh.Commands.GMC;
import lrxh.Commands.GMS;
import lrxh.Commands.InvSee;
import lrxh.Commands.LockChat;
import lrxh.Commands.Report;
import lrxh.Commands.StaffChat;
import lrxh.Commands.StaffList;
import lrxh.Commands.Tp;
import lrxh.Commands.Vanish;

public class Main extends JavaPlugin {
	

    public void onEnable() {
        // commands
        getCommand("gmc").setExecutor(new GMC());
        getCommand("gms").setExecutor(new GMS());
        getCommand("sc").setExecutor(new StaffChat());
        getCommand("cps").setExecutor(new CpsCounter(this));
        getCommand("stafflist").setExecutor(new StaffList(this));
        getCommand("vanish").setExecutor(new Vanish(this));
        getCommand("v").setExecutor(new Vanish(this));
        getCommand("invsee").setExecutor(new InvSee());
        getCommand("report").setExecutor(new Report());
        getCommand("fly").setExecutor(new Fly());
        getCommand("tp").setExecutor(new Tp());
        getCommand("lockc").setExecutor(new LockChat(this));
        getCommand("clearc").setExecutor(new ClearChat());
        
        // load config
        getConfig().options().copyDefaults(true);
        saveConfig();
        Constants.loadConfig(this);
        getLogger().info("Configuration loaded successfully.");
        Bukkit.getConsoleSender().sendMessage(ChatColor.GREEN + "StaffCore" + " started! Made by " + ChatColor.LIGHT_PURPLE + "lrxh#0001");
    }

    public void onDisable() {
    }
}
