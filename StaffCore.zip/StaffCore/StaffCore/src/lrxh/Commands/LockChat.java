package lrxh.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.Plugin;

import lrxh.Constants;

public class LockChat implements CommandExecutor, Listener {

    private static boolean chatLocked = false;

    public LockChat(Plugin plugin) {
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(Constants.getPerm())) {
            sender.sendMessage(Constants.getNoPerms());
            return true;
        }

        chatLocked = !chatLocked;

        if (chatLocked) {
            Bukkit.broadcastMessage(ChatColor.RED + "Chat has been locked. Only staff members can send messages.");
        } else {
            Bukkit.broadcastMessage(ChatColor.GREEN + "Chat has been unlocked. All players can send messages.");
        }

        return true;
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (chatLocked && !player.hasPermission(Constants.getPerm())) {
            player.sendMessage(ChatColor.RED + "Chat is currently locked. You cannot send messages.");
            event.setCancelled(true);
        }
    }

    public static boolean isChatLocked() {
        return chatLocked;
    }
}
