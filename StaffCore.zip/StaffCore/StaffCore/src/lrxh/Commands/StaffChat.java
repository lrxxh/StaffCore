package lrxh.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lrxh.Constants;

public class StaffChat implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission(Constants.getPerm())) {
            player.sendMessage(Constants.getNoPerms());
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(ChatColor.RED + "Usage: /sc <message>");
            return true;
        }

        String message = String.join(" ", args);
        String formattedMessage = Constants.getPrefix() + ChatColor.GRAY + player.getName() + ": " + ChatColor.WHITE + message;

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("GAC.SC")) {
                staff.sendMessage(formattedMessage);
            }
        }

        return true;
    }
}
