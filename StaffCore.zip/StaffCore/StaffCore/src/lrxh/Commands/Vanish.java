package lrxh.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import lrxh.Constants;

public class Vanish implements CommandExecutor, Listener {
    private Scoreboard scoreboard;

    public Vanish(Plugin plugin) {
        this.scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    private void vanishPlayer(Player player) {
        Team team = scoreboard.getTeam("vanish");
        if (team == null) {
            team = scoreboard.registerNewTeam("vanish");
        }

        team.addEntry(player.getName());

        player.setPlayerListName(ChatColor.RESET.toString());

        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (!onlinePlayer.equals(player)) {
                onlinePlayer.hidePlayer(player);
            }
        }
    }

    private void unvanishPlayer(Player player) {
        Team team = scoreboard.getTeam("vanish");
        if (team != null) {
            team.removeEntry(player.getName());
        }
        player.setPlayerListName(player.getName());

        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            onlinePlayer.showPlayer(player);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission(Constants.getPerm())) {
            player.sendMessage(Constants.getNoPerms());
            return true;
        }

        if (scoreboard.getTeam("vanish").hasEntry(player.getName())) {
            unvanishPlayer(player);
            sender.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "You are no longer vanished.");
        } else {
            vanishPlayer(player);
            sender.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "You have been vanished.");
        }

        return true;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        for (Player vanishedPlayer : Bukkit.getOnlinePlayers()) {
            if (scoreboard.getTeam("vanish").hasEntry(vanishedPlayer.getName())) {
                player.hidePlayer(vanishedPlayer);
            }
        }
    }
}
