package lrxh.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import lrxh.Constants;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CpsCounter implements CommandExecutor, Listener {

    private final Plugin plugin;
    private final Map<UUID, Integer> clickCounts;

    public CpsCounter(Plugin plugin) {
        this.plugin = plugin;
        this.clickCounts = new HashMap<>();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        
        Player player = (Player) sender;
        if (!player.hasPermission(Constants.getPerm())) {
            player.sendMessage(Constants.getNoPerms());
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /cps <username>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || !target.isOnline()) {
            sender.sendMessage("The specified player is not online.");
            return true;
        }

        UUID targetUUID = target.getUniqueId();
        clickCounts.put(targetUUID, 0);

        sender.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "Scanning " + target.getName() + "'s CPS...");

        new BukkitRunnable() {
            @Override
            public void run() {
                int clickCount = clickCounts.remove(targetUUID);
                int cps = clickCount / 10;
                sender.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + target.getName() + "'s CPS: " + ChatColor.WHITE + "~" + cps);
            }
        }.runTaskLater(plugin, 200L); 
        return true;
    }

    @EventHandler
    public void onPlayerClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        UUID playerUUID = player.getUniqueId();
        if (clickCounts.containsKey(playerUUID)) {
            clickCounts.put(playerUUID, clickCounts.get(playerUUID) + 1);
        }
    }
}
