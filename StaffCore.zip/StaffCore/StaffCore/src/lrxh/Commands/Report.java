package lrxh.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lrxh.Constants;

import java.util.Arrays;

public class Report implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command.");
            return true;
        }

        Player reporter = (Player) sender;

        if (args.length < 2) {
            reporter.sendMessage(ChatColor.RED + "Usage: /report <username> <reason>");
            return true;
        }

        String reportedPlayerName = args[0];
        String reason = String.join(" ", Arrays.copyOfRange(args, 1, args.length));

        Player reportedPlayer = Bukkit.getPlayer(reportedPlayerName);

        if (reportedPlayer == null || !reportedPlayer.isOnline()) {
            reporter.sendMessage(ChatColor.RED + reportedPlayerName + " is not online.");
            return true;
        }

        String reportMessage = Constants.getStaffReport() + reporter.getName() + " reported " +ChatColor.WHITE + reportedPlayer.getName() + ChatColor.GRAY + " for "+ ChatColor.WHITE + reason;

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission(Constants.getPerm())) {
                staff.sendMessage(reportMessage);
            }
        }

        reporter.sendMessage(ChatColor.GREEN + "Your report has been sent to staff members.");

        return true;
    }
}
