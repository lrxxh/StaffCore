package lrxh.Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lrxh.Constants;

public class ClearChat implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            if (!player.hasPermission(Constants.getPerm())) {
                player.sendMessage(Constants.getNoPerms());
                return true;
            }

            for (int i = 0; i < 100; i++) {
                player.sendMessage("");
            }

            player.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "Chat has been cleared.");
        } else {
            sender.sendMessage("This command can only be used by players.");
        }

        return true;
    }
}
