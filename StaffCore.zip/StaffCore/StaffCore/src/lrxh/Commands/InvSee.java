package lrxh.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import lrxh.Constants;

public class InvSee implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission(Constants.getPerm())) {
            player.sendMessage(Constants.getNoPerms());
            return true;
        }
        
        if (args.length != 1) {
            player.sendMessage(ChatColor.RED + "Usage: /invsee <username>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);

        if (target == null) {
            player.sendMessage(ChatColor.RED + "Player " + args[0] + " is not online.");
            return true;
        }

        Inventory targetInventory = target.getInventory();

        player.openInventory(targetInventory);
        player.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "Viewing inventory of " + target.getName());

        return true;
    }
}
