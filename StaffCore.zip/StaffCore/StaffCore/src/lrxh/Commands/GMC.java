package lrxh.Commands;

import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lrxh.Constants;

public class GMC implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        Player player = (Player) sender;
        if (!player.hasPermission(Constants.getPerm())) {
            player.sendMessage(Constants.getNoPerms());
            return true;
        }

        player.setGameMode(GameMode.CREATIVE);
        sender.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "gamemode set to Creative.");
        return true;
    }
}
