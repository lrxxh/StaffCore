package lrxh.Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import lrxh.Constants;

public class Fly implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission(Constants.getPerm())) {
            player.sendMessage(Constants.getNoPerms());
            return true;
        }

        if (player.getAllowFlight()) {
            player.setAllowFlight(false);
            player.setFlying(false);
            player.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "Flight mode disabled.");
        } else {
            player.setAllowFlight(true);
            player.sendMessage(Constants.getPrefix() + Constants.getSecondColor() + "Flight mode enabled.");
        }

        return true;
    }
}
