package lrxh.Commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import lrxh.Constants;
import net.md_5.bungee.api.ChatColor;


public class StaffList implements CommandExecutor {

    private final Plugin plugin;

    public StaffList(Plugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(Constants.getPerm())) {
            sender.sendMessage(Constants.getNoPerms());
            return true;
        }

        StringBuilder staffList = new StringBuilder();
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (player.hasPermission("gac.staff")) {
                staffList.append(player.getName()).append("\n");
            }
        }

        if (staffList.length() == 0) {
            sender.sendMessage(ChatColor.BLUE + "No staff members online.");
        } else {
            sender.sendMessage(ChatColor.BLUE + "Online Staff Members:");
            sender.sendMessage(ChatColor.GRAY + staffList.toString().trim());
        }

        return true;
    }
}
