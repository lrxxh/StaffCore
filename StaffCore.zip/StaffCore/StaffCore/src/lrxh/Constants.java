package lrxh;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

public class Constants {

    private static FileConfiguration config;

    public static void loadConfig(Plugin plugin) {
        config = plugin.getConfig();
    }

    public static ChatColor getMainColor() {
        return ChatColor.valueOf(config.getString("MainColor"));
    }

    public static ChatColor getSecondColor() {
        return ChatColor.valueOf(config.getString("SecondColor"));
    }

    public static String getPrefix() {
        return Constants.getMainColor() + config.getString("prefix") + Constants.getSeparator();
    }
    
    public static ChatColor getSeparatorColor() {
        return ChatColor.valueOf(config.getString("SeparatorColor"));

    }
    public static String getSeparator() {
        return Constants.getSeparatorColor() + config.getString("Separator");
    }

    public static String getStaffReport() {
        return Constants.getMainColor() + config.getString("StaffReport") + Constants.getSeparator() + Constants.getSecondColor();
    }

    public static String getNoPerms() {
        return ChatColor.RED + config.getString("NoPermsError");
    }

    public static String getPerm() {
        return config.getString("Permission");
    }
}
